From one bit to a fitted polynomial: engineered spectral filters for track
reconstruction in a noisy LHCb VELO toy model — G. W. Scriven

Overleaf: upload this zip as a new project. Main document: main.tex.
Compiler: pdfLaTeX (default). No BibTeX run is needed — the bibliography is
inline (thebibliography). Three passes resolve every reference.

Contents
  main.tex               the paper (67 pages at the 3 September 2026 build)
  figures/               37 figure files referenced by main.tex
  figures/*.tex          four hand-drawn TikZ circuit figures (\input)
